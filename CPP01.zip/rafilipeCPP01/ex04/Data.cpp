#include "Data.hpp"

Data::Data() 
{
	std::cout << "Constructor is called" << std::endl;
}

Data::~Data() 
{
	std::cout << "Destructor is called" << std::endl;
}
