#include <iostream>
#include <fstream>
#include "Data.hpp"

int main(int ac, char **av)
{
	if (ac == 4)
	{
		std::string filename = av[1];
		std::ifstream infile(filename.c_str());
		std::string line;
		std::string str1 = av[2];
		std::string str2 = av[3];

		if (!str1.length() || !infile.is_open())
			return (1);
		std::ofstream outfile((filename + ".replace").c_str());
		if (infile && outfile && outfile.is_open())
		{
			while (getline(infile, line))
			{
				std::size_t found;
				found = line.find(str1);
				while (found != std::string::npos)
				{
					line.erase(found, str1.length());
					line.insert(found, str2);
					found = line.find(str1, found + str2.length());
				}
				outfile << line << std::endl;
			}
		}
		infile.close();
		outfile.close();
	}
	else
		std::cout << "Syntax Error: ./sed [filename] [str1] [str2]" << std::endl;
}
