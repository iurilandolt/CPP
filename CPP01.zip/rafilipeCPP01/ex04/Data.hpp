#ifndef DATA_H
#define DATA_H

#include <iostream>

class Data
{
	private:
	const std::string	str1;
	const std::string	str2;
	int					fd;

	public:
		Data();
		~Data();


};

#endif
