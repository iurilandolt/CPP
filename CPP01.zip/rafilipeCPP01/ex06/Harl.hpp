#ifndef HARL_H
#define HARL_H

#include <iostream>

class Harl
{
	private:
		void		debug(void);
		void		info(void);
		void		warning(void);
		void		error(void);
		std::string	_level[4];
		void (Harl::*f[4])(void);
	public:
		Harl();
		~Harl();

		void	complain(std::string level);
		void	defaultMessage(void);
};

#endif
