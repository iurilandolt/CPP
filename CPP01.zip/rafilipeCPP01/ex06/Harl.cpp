#include "Harl.hpp"

Harl::Harl()
{
	std::cout << "Constructor is called" << std::endl;
	this->_level[0] = "DEBUG";
	this->_level[1] = "INFO";
	this->_level[2] = "WARNING";
	this->_level[3] = "ERROR";
	this->f[0] = &Harl::debug;
	this->f[1] = &Harl::info;
	this->f[2] = &Harl::warning;
	this->f[3] = &Harl::error;
}

Harl::~Harl()
{
	std::cout << "Destructor is called" << std::endl;
}

void Harl::complain(std::string level)
{
	int i;
	for (i = 0; i < 4; i++)
	{
		if (this->_level[i] == level)
			break;
	}
	switch (i)
	{
	case 0:
	{
		(this->*f[i])();
		i++;
	}
	case 1:
	{
		(this->*f[i])();
		i++;
	}
	case 2:
	{
		(this->*f[i])();
		i++;
	}
	case 3:
	{
		(this->*f[i])();
		i++;
	}
		break;
	default:
		this->defaultMessage();
	}
}

void Harl::defaultMessage()
{
	std::cout << "[Probably complaining about insignificant problems]" << std::endl;
}

void Harl::debug(void)
{
	std::cout << "[ DEBUG ]" << std::endl;
	std::cout << "Useful info here. Used for problem diagnosis" << std::endl;
	std::cout << std::endl;
}

void Harl::info(void)
{
	std::cout << "[ INFO ]" << std::endl;
	std::cout << "Extensive info here. Tracing program execution in production" << std::endl;
	std::cout << std::endl;
}

void Harl::warning(void)
{
	std::cout << "[ WARNING ]" << std::endl;
	std::cout << "Potencial Issue. It can be handled or ignored" << std::endl;
	std::cout << std::endl;

}

void Harl::error(void)
{
	std::cout << "[ ERROR ]" << std::endl;
	std::cout << "Unrecoverable error. Critical issue that requires manual intervention" << std::endl;
	std::cout << std::endl;
}