/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rafilipe <rafilipe@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/17 01:23:43 by rafilipe          #+#    #+#             */
/*   Updated: 2023/11/17 01:40:16 by rafilipe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

int main()
{
	Zombie *zombie1 = newZombie("Zombie 1");
	zombie1->announce();
	delete zombie1;
	std::cout << std::endl;

	randomChump("Zombie 4");
	std::cout << std::endl;
	randomChump("Zombie 5");
	std::cout << std::endl;
	
	Zombie *zombie2 = newZombie("Zombie 2");
	zombie2->announce();
	delete zombie2;
	std::cout << std::endl;
	
}