#include "Harl.hpp"

Harl::Harl() 
{
	std::cout << "Constructor is called" << std::endl;
	this->_level[0] = "DEBUG";
	this->_level[1] = "INFO";
	this->_level[2] = "WARNING";
	this->_level[3] = "ERROR";
	this->f[0] = &Harl::debug;
	this->f[1] = &Harl::info;
	this->f[2] = &Harl::warning;
	this->f[3] = &Harl::error;
}


Harl::~Harl() 
{
	std::cout << "Destructor is called" << std::endl;
}

void	Harl::complain(std::string level)
{
	for (int i = 0; i < 4; i++)
	{
		if (this->_level[i] == level)
			(this->*f[i])();
	}
}

void	Harl::debug(void)
{
	std::cout << "DEBUG: Useful info here. Used for problem diagnosis" << std::endl;
}

void	Harl::info(void)
{
	std::cout << "INFO: Extensive info here. Tracing program execution in production" << std::endl;
}

void	Harl::warning(void)
{
	std::cout << "WARNING: Potencial Issue. It can be handled or ignored" << std::endl;
}

void	Harl::error(void)
{
	std::cout << "ERROR: Unrecoverable error. Critical issue that requires manual intervention" << std::endl;
}