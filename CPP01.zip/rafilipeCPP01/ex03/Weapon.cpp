/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rafilipe <rafilipe@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/17 02:55:08 by rafilipe          #+#    #+#             */
/*   Updated: 2023/11/17 15:10:45 by rafilipe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"

Weapon::Weapon(std::string type)
{
	std::cout << "Weapon Constructor is called" << std::endl;
	this->_type = type;
}

Weapon::~Weapon()
{
	std::cout << "Weapon Destructor is called" << std::endl;
}

std::string const &Weapon::getType() const
{
	return this->_type;
}

void	Weapon::setType(std::string weapon)
{
	this->_type = weapon;
}