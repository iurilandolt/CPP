/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rafilipe <rafilipe@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/17 02:41:46 by rafilipe          #+#    #+#             */
/*   Updated: 2023/11/17 02:51:11 by rafilipe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

int main()
{
	std::string var = "HI THIS IS BRAIN";
	std::string *var1 = &var;
	std::string	&var2 = var;

	std::cout << &var << std::endl;
	std::cout << var1 << std::endl;
	std::cout << &var2 << std::endl;
	std::cout << std::endl;
	
	std::cout << var << std::endl;
	std::cout << *var1 << std::endl;
	std::cout << var2 << std::endl;
}