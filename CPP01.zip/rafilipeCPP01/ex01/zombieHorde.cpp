/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   zombieHorde.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rafilipe <rafilipe@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/17 01:49:03 by rafilipe          #+#    #+#             */
/*   Updated: 2023/11/17 02:39:04 by rafilipe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

Zombie* zombieHorde( int n, std::string name)
{
	if (n < 0)
		return NULL;
	Zombie	*hoard = new Zombie[n];
	std::cout << std::endl;
	for (int i = 0; i < n; i++)
	{
		std::stringstream temp;
		temp << name << i + 1;
		hoard[i].setName(temp.str());
		hoard[i].announce();
	}
	std::cout << std::endl;
	return hoard;
}