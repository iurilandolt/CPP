/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rafilipe <rafilipe@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/17 02:15:42 by rafilipe          #+#    #+#             */
/*   Updated: 2023/11/17 02:38:43 by rafilipe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

int main()
{
	int hoardSize;

	std::cout << "Enter number of Zombies: ";
	std::cin >> hoardSize;
	Zombie	*hoard = zombieHorde(hoardSize, "Zombie");
	delete [] hoard;
}