/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 16:49:32 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/07 17:38:25 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Harl.hpp"

int main(int argc, char **argv)
{
    Harl harl;

    std::cout << std::endl;
    if (argc == 1)
    {
        std::cout << "Has anyone seen Harl?\n";
        std::cout << std::endl;
        return (0);
    }
    if (argc > 2)
    {
        std::cout << "Harl is speaking too fast!\n";
        std::cout << std::endl;
        return (0);
    }
    harl.complain (argv[1]);
    std::cout << std::endl;
}