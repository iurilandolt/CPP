/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:13:47 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 17:25:15 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>

#include <iostream>

int main()
{
    std::string     message = "HI THIS IS BRAIN";
    std::string*    stringPTR = &message;
    std::string&    stringREF = message;

    std::cout << &message << std::endl;
    std::cout << &stringPTR << std::endl;
    std::cout << &stringREF << std::endl;

    std::cout << message << std::endl;
    std::cout << *stringPTR << std::endl;
    std::cout << stringREF << std::endl;
}