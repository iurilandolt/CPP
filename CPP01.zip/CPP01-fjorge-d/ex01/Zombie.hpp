/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 15:45:00 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 17:10:19 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HPP
#define ZOMBIE_HPP

#include <string>
#include <iostream>

class Zombie
{    
    private:
    
        std::string name;

    public:

        Zombie();
        ~Zombie();

        void    announce( void );
        void    nameZombie( std::string name );
};

Zombie* zombieHorde( int N, std::string name );

#endif