/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 15:43:45 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/17 14:15:45 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

Zombie::Zombie()
{
    std::cout << "Zombie created!" << std::endl;
}

Zombie::~Zombie()
{
    std::cout << "Zombie " << name << " destroyed!" << std::endl;
}

void Zombie::announce()
{
    std::cout << name;
    std::cout << ": BraiiiiiiinnnzzzZ..." << std::endl;
}

void Zombie::nameZombie( std::string name )
{
    this->name = name;
}