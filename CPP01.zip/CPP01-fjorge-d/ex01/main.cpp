/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlandolt <rlandolt@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 15:42:48 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/17 15:40:22 by rlandolt         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

int main()
{
    Zombie* horde;

    horde = zombieHorde(5, "Citizen");
	horde[0].announce();
    horde[1].announce();
    horde[3].announce();
    delete[] horde;
}
