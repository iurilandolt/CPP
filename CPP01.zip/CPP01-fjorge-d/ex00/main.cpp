/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 15:42:48 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 16:12:06 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

int main()
{
    Zombie* pedro;
    Zombie* joao;

    pedro = newZombie ("Pedro");
    joao = newZombie ("Joao");
    randomChump ("Ana");
    joao->announce();
    delete pedro;
    delete joao;
}