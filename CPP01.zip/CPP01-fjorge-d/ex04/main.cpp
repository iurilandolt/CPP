/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 18:44:24 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/07 15:14:33 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>
#include <string>

std::string replace(std::string str, const std::string& s1, const std::string& s2)
{
    int len;
    int aux;

    aux = 0;
    while (aux != -1)
    {
        aux = str.find (s1, aux);
        if (aux == -1)
            break;
        len = s1.size() + aux;
        str = str.substr(0, aux) + s2 + str.substr(len, str.size() - len);
    }
    return (str);
}

int main(int argc, char **argv)
{
    std::string     input;
    std::string     str;
    std::ifstream   in;
    std::ofstream   out;

    if (argc != 4)
    {
        std::cout << "Wrong number of parameters!\n";
        return (0);
    }
    in.open(argv[1]);
    if (!in.is_open())
    {
        std::cout << "Error: Can't open file!\n";
        return (0);
    }
    str = argv[1];
    str += ".replace";
    out.open(str.c_str(), std::ofstream::trunc);
    if (!out.is_open())
    {
        in.close();
        std::cout << "Error creating file!\n";
        return (0);
    }
    std::getline(in, input);
    while (in.good())
    {
        std::getline(in, str);
        input += "\n" + str;
    }
    input = replace(input, argv[2], argv[3]);
    out << input;
    in.close();
    out.close();
    return (0);
}