/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:41:15 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 18:38:50 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "HumanB.hpp"

HumanB::HumanB( std::string name )
{
    this->weapon = NULL;
    this->name = name;
    std::cout << name << " has arrived!\n";
}

HumanB::~HumanB()
{
    std::cout << name << " has died!\n";
}

void HumanB::attack()
{
    if (weapon != NULL)
        std::cout << name << " attacks with their " << weapon->getType() << std::endl;
    else
        std::cout << name << " has no weapon!\n";
}

void HumanB::setWeapon( Weapon *weapon )
{
    this->weapon = weapon;
    if (weapon != NULL)
        std::cout << name << " has picked up a " << weapon->getType() << std::endl;
}