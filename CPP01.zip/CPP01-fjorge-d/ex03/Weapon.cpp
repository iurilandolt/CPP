/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:27:30 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 18:36:38 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"

Weapon::Weapon( std::string type )
{
    this->type = type;
    std::cout << "A " << type << " was created!\n";
}

Weapon::~Weapon()
{
    std::cout << "A " << type << " was destroyed!\n";
}

const std::string& Weapon::getType() const
{
    const std::string& ref = type;
    return (ref);
}

void Weapon::setType( std::string type )
{
    std::cout << "Weapon: " << this->type << " is now a ";
    this->type = type;
    std::cout << type << std::endl;
}