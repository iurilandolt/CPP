/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanA.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:35:10 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 18:36:52 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "HumanA.hpp"

HumanA::HumanA( std::string name, const Weapon& weapon ) : weapon(weapon)
{
    this->name = name;
    std::cout << name << " has arrived!\n";
}

HumanA::~HumanA()
{
    std::cout << name << " has died!\n";
}

void HumanA::attack() const
{
    std::cout << name << " attacks with their " << weapon.getType() << std::endl;
}