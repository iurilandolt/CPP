/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:39:58 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 18:39:21 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMANB_CPP
#define HUMANB_CPP

#include "Weapon.hpp"

class HumanB
{
    private:

        std::string name;
        Weapon* weapon;

    public:

        HumanB( std::string name );
        ~HumanB();
        
        void    attack();
        void    setWeapon( Weapon *weapon );
};

#endif