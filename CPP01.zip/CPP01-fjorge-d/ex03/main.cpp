/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:27:01 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 18:39:37 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"
#include "HumanA.hpp"
#include "HumanB.hpp"

int main()
{
    Weapon sword = Weapon("sword");
    Weapon spear = Weapon("spear");
    Weapon club = Weapon("club");
    std::cout << std::endl;

    HumanA george = HumanA("George", club);
    HumanB henry = HumanB("Henry");
    HumanA joseph = HumanA("Joseph", spear);
    std::cout << std::endl;

    std::cout << "Joseph has a " << spear.getType() << std::endl;
    spear.setType("glock");
    joseph.attack();
    henry.attack();
    henry.setWeapon(&sword);
    henry.attack();
    george.attack();
    std::cout << std::endl;
}