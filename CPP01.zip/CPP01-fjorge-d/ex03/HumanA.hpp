/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanA.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/03 17:35:42 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/03 18:38:03 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMANA_CPP
#define HUMANA_CPP

#include "Weapon.hpp"

class HumanA
{
    private:

        std::string name;
        const Weapon& weapon;

    public:

        HumanA( std::string name, const Weapon& weapon );
        ~HumanA();
        
        void attack() const;
};

#endif
