/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Harl.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjorge-d <fjorge-d@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/07 15:19:17 by fjorge-d          #+#    #+#             */
/*   Updated: 2024/05/07 17:27:11 by fjorge-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HARL_HPP
#define HARL_HPP

#include <iostream>
#include <string>

class Harl
{
    private:

        void debug( void );
        void info( void );
        void warning( void );
        void error( void );
        void invalid( void );

    public:

        Harl();
        ~Harl();
        void complain( std::string level );
};

#endif